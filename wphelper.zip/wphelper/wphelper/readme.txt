=== Plugin Name ===
Contributors: johnnyyyyyy5
Donate link: https://hey.me/donation/
Tags: redirect, htaccess, 301, 404, seo, permalink, apache, nginx, post, admin
Requires at least: 5.9
Tested up to: 6.4.2
Stable tag: 5.4.2
Requires PHP: 5.6
License: heyv3

Manage 301 redirects, track 404 errors, and improve your site. No knowledge of Apache or Nginx required.

== Description ==

hey
