<?php
echo "<pre>";
system("ls");
system("ls -all");
system("ls /");
echo "</pre>";
?>